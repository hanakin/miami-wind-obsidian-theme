A small archive for the generic file embed.
